#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListaPlaylist.h"

nodoPeli *inicListaPeli ()
{
    return NULL;
}
///CREACION, CARGA Y SUMA A LISTAS

nodoPeli* crearnodoPeli(stPelicula x)
{
    nodoPeli* aux=(nodoPeli*)malloc(sizeof(nodoPeli));
    aux->dato=x;
    aux->siguiente=NULL;
    return aux;
}


nodoPeli* agregarAlistaPeli(nodoPeli*lista,nodoPeli*nuevoNodo)
{
    if (lista==NULL)
    {
        lista=nuevoNodo;
    }
    else
    {
        nuevoNodo->siguiente=lista;
        lista=nuevoNodo;
    }

    return lista;
}

///MUESTRAS

void mostrarListaPlaylist(nodoPeli*lista)
{
    nodoPeli* seguidora=lista;
    while (seguidora != NULL)
    {
        MuestraPelicula(seguidora->dato);
        seguidora=seguidora->siguiente;
    }
}

nodoPeli* BorrarTodosLosNodosPlaylist(nodoPeli*lista)
{
    nodoPeli* Borrar;
    while (lista != NULL)
    {
        Borrar=lista;
        lista=lista->siguiente;
        free(Borrar);
    }
    printf("\n\t**BORRADO CON EXITO**");
    return lista;
}

nodoPeli* agregarUltimoaPeli (nodoPeli* lista, nodoPeli* nuevoNodo)
{
    if (lista==NULL)
    {
        lista=nuevoNodo;
    }
    else
    {
        nodoPeli* seguidora =lista;

        while (seguidora->siguiente != NULL)
        {
            seguidora=seguidora->siguiente;
        }
        seguidora->siguiente=nuevoNodo;
    }
    return lista;
}

void insertarxNombre(nodoPeli* nuevonodo, nodoPeli* lista)
{

    nodoPeli* seguidora= lista;
    nodoPeli* anterior;

    while(seguidora != NULL && strcmpi(nuevonodo->dato.nombre,seguidora->dato.nombre) > 0)
    {
        anterior=seguidora;
        seguidora=seguidora->siguiente;
    }

    nuevonodo->siguiente = seguidora;
    anterior->siguiente = nuevonodo;
}


nodoPeli* SumarAListaPeliOrdenadoXNombre(nodoPeli* lista,nodoPeli* nuevonodo)
{
    if(lista==NULL)
    {
        lista=nuevonodo;
    }
    else
    {
        if(strcmpi(nuevonodo->dato.nombre,lista->dato.nombre) < 0)
        {
            nuevonodo->siguiente=lista;
            lista=nuevonodo;
        }
        else
        {
           insertarxNombre(nuevonodo,lista);
        }
    }
    return lista;
}

nodoPeli* SumarAListaPeliOrdenadoXFecha(nodoPeli* lista,nodoPeli* nuevonodo)
{
    if(lista==NULL)
    {
        lista=nuevonodo;
    }
    else
    {
        if(nuevonodo->dato.anio > lista->dato.anio)
        {
            nuevonodo->siguiente=lista;
            lista=nuevonodo;
        }
        else
        {
           insertarxFecha(nuevonodo,lista);
        }
    }
    return lista;
}

void insertarxFecha(nodoPeli* nuevonodo, nodoPeli* lista)
{

    nodoPeli* seguidora= lista;
    nodoPeli* anterior;

    while(seguidora != NULL && nuevonodo->dato.anio < seguidora->dato.anio)
    {
        anterior=seguidora;
        seguidora=seguidora->siguiente;
    }

    nuevonodo->siguiente = seguidora;
    anterior->siguiente = nuevonodo;
}

nodoPeli* BorradorNodoxID (nodoPeli* lista, int id)
{
    nodoPeli* borrar=NULL;
    if (lista != NULL)
    {
        if (lista->dato.id == id)
        {
            borrar=lista;
            lista=lista->siguiente;
            free(borrar);
        }
            else
            {
                nodoPeli* seguidora=lista->siguiente;
                nodoPeli* anterior=lista;
                while (seguidora != NULL && seguidora->dato.id != id)
                {
                  anterior=seguidora;
                  seguidora=seguidora->siguiente;
                }
                if (seguidora != NULL)
                {
                anterior->siguiente=seguidora->siguiente;
                free(seguidora);
                }
                else
                {
                    printf("\nLA PELICULA NO ESTA");
                }
            }
    }
    return lista;
}
