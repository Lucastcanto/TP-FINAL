#ifndef LISTADEUSUARIOS_H_INCLUDED
#define LISTADEUSUARIOS_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "ListaPlaylist.h"

typedef struct
{
    int id;
    char apellidoYnombres [50];
    char mail [50];
    int celular;
    char contrasenia [8];
    int estado;
    int categoria;

} stUsuario;

typedef struct
{
    int id;
    char apellidoYnombres [50];
    char mail [50];
    int celular;
    char contrasenia [8];
    int estado;
    int IdPlaylist[10];
    int validosPlay;
    int categoria;

} stUsuarioARCH;


typedef struct
{
    stUsuario dato;
    struct nodoPeli* playlist;
    struct nodoUser *siguiente;

}nodoUser;

///PROTOTIPADO---------------------------------------
nodoUser*inicListaUser ();
nodoUser* crearnodoUser(stUsuario x);
nodoUser* agregarAlistaUser(nodoUser*lista,nodoUser*nuevoNodo);
void mostrarUser(stUsuario x);
void mostrarListaUser(nodoUser*lista);
nodoUser* DespersistenciaUsuario (nodoUser*listaUser,nodoArbol* arbol);
stUsuario ArchivoAUsuario (stUsuarioARCH dato);
nodoPeli* CargarPlaylist(nodoPeli* playlist,int arr[],int validos,nodoArbol* arbol);
nodoUser* BuscarUsuarioNombre(nodoUser* listaUser,char nombre[]);
nodoUser* BuscarUsuarioID(nodoUser* listaUser,int id);
void AgregarPeliculaUsuario(nodoUser* listaUsu,stPelicula peli);
nodoUser* BorrarTodosLosNodosUser(nodoUser*lista);
int VerificarContrasenia(nodoUser* listaUser,char contra[]);
stUsuario CargaUsuario();
int ContarUsuarios(nodoUser* lista);
void borrarUsuario (nodoUser* lista);
void RecorrerListaPersistencia(nodoUser*lista,FILE*fp);
void PersitenciaListaUsuarios(nodoUser* lista);
stUsuarioARCH USUaARCH (nodoUser* nodo);
int PlaylistAArreglo(nodoPeli* lista,stUsuarioARCH aux);
///--------------------------------------------------
#endif // LISTADEUSUARIOS_H_INCLUDED
