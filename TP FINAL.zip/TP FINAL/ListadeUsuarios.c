#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListadeUsuarios.h"

nodoUser *inicListaUser ()
{
    return NULL;
}

nodoUser* crearnodoUser(stUsuario x)
{
    nodoUser* aux=(nodoUser*)malloc(sizeof(nodoUser));
    aux->dato=x;
    aux->siguiente=NULL;
    aux->playlist=NULL;
    return aux;
}


nodoUser* agregarAlistaUser(nodoUser*lista,nodoUser*nuevoNodo)
{
    if (lista==NULL)
    {
        lista=nuevoNodo;
    }
    else
    {
        nuevoNodo->siguiente=lista;
        lista=nuevoNodo;
    }

    return lista;
}

///MUESTRAS

void mostrarUser(stUsuario x)
{
    printf("\nNombre: ");
    puts(x.apellidoYnombres);
    printf("ID:");
    printf("%i",x.id);
    printf("\nMail:");
    puts(x.mail);
    printf("Celular:");
    printf(" %i",x.celular);
    printf("\nContrasenia: ");
    puts(x.contrasenia);
}

void mostrarListaUser(nodoUser*lista)
{
    nodoUser* seguidora=lista;
    while (seguidora != NULL)
    {
        mostrarUser(seguidora->dato);
        seguidora=seguidora->siguiente;
    }
}
///PERSISTENCIA Y DESPERSISTENCIA


nodoUser* DespersistenciaUsuario (nodoUser*listaUser,nodoArbol* arbol)
{
    stUsuarioARCH aux;
    stUsuario usu;
    nodoUser* nuevoNodoUser;
    FILE *fp = fopen ("UsuariosARCH.bin","rb");
    if (fp != NULL)
    {
        while (fread(&aux,sizeof(stUsuarioARCH),1,fp)>0)
        {
            usu=ArchivoAUsuario(aux);

            nuevoNodoUser=crearnodoUser(usu);

            nuevoNodoUser->playlist=CargarPlaylist(nuevoNodoUser->playlist,aux.IdPlaylist,aux.validosPlay,arbol);

            listaUser=agregarAlistaUser(listaUser,nuevoNodoUser);
        }
        fclose(fp);
    }
    return listaUser;
}

stUsuario ArchivoAUsuario (stUsuarioARCH dato)
{
    stUsuario aux;
    strcpy(aux.apellidoYnombres,dato.apellidoYnombres);
    strcpy(aux.contrasenia,dato.contrasenia);
    strcpy(aux.mail,dato.mail);
    aux.categoria=dato.categoria;
    aux.celular=dato.celular;
    aux.id=dato.id;
    aux.estado=dato.estado;

    return aux;
}

nodoPeli* CargarPlaylist(nodoPeli* playlist,int arr[],int validos,nodoArbol* arbol)
{
    nodoArbol* aux;
    for (int i=0; i < validos; i++)
    {
        aux=BuscarEnArbol(arbol,arr[i]);
        if (aux != NULL)
        {
            playlist=agregarAlistaPeli(playlist,crearnodoPeli(aux->peli));
        }
    }
    return playlist;
}

nodoUser* BuscarUsuarioNombre(nodoUser* listaUser,char nombre[])
{
    nodoUser* seguidora=listaUser;
    nodoUser* rta=NULL;
    while ((seguidora != NULL) && (strcmpi(seguidora->dato.apellidoYnombres,nombre)!= 0))
    {
        seguidora=seguidora->siguiente;
    }
    if (seguidora != NULL)
    {
        rta=seguidora;
    }
    return rta;
}

nodoUser* BuscarUsuarioID(nodoUser* listaUser,int id)
{
    nodoUser* seguidora=listaUser;
    nodoUser* rta=NULL;
    while ((seguidora != NULL) && (seguidora->dato.id != id))
    {
        seguidora=seguidora->siguiente;
    }
    if (seguidora != NULL)
    {
        rta=seguidora;
    }
    return rta;
}

int VerificarContrasenia(nodoUser* user,char contra[])
{
    nodoUser* seguidora=user;
    int rta=-1;
    if (strcmp(seguidora->dato.contrasenia,contra)== 0)
    {
        rta=1;
    }
    return rta;
}

stUsuario CargaUsuario()
{
    stUsuario x;
    printf("\nNOMBRE Y APELLIDO: ");
    fflush(stdin);
    gets(x.apellidoYnombres);

    printf("\nMAIL: ");
    fflush(stdin);
    gets(x.mail);

    printf("\nCELULAR: ");
    scanf("%i",&x.celular);

    printf("\nCONTRASENIA: ");
    fflush(stdin);
    gets(x.contrasenia);

    return x;
}

int ContarUsuarios(nodoUser* lista)
{
    int contador=0;
    nodoUser* seguidora=lista;

    while (seguidora != NULL)
    {
        contador++;
        seguidora=seguidora->siguiente;
    }

    return contador;
}

nodoUser* BorrarTodosLosNodosUser(nodoUser*lista)
{
    nodoUser* Borrar;
    while (lista != NULL)
    {
        lista->playlist=BorrarTodosLosNodosPlaylist(lista->playlist);
        Borrar=lista;
        lista=lista->siguiente;
        free(Borrar);
    }
    return lista;
}

void AgregarPeliculaUsuario(nodoUser* listaUsu,stPelicula peli)
{
listaUsu->playlist=agregarAlistaPeli(listaUsu->playlist,crearnodoPeli(peli));
}

void borrarUsuario (nodoUser* lista)
{
    char aux [50];
    printf("\nQue usuario desea eliminar?");
    fflush(stdin);
    gets(aux);
    nodoUser* X;
    X=BuscarUsuarioNombre(lista,aux);
    if(X == NULL)
    {
        printf("\nUsuario no existente");
    }
    else
    {
        X->dato.estado=0;
        printf("\n\t**BORRADO CON EXITO**");
    }

}

void PersitenciaListaUsuarios(nodoUser* lista)
{
    FILE*fp=fopen("UsuariosARCH.bin","wb");
    if (fp != NULL)
    {
        RecorrerListaPersistencia(lista,fp);
        fclose(fp);
    }
}
void RecorrerListaPersistencia(nodoUser*lista,FILE*fp)
{
    stUsuarioARCH aux;
    nodoUser* seguidora=lista;
    while (seguidora != NULL)
    {
        aux=USUaARCH(seguidora);
        fwrite(&aux,sizeof(stUsuarioARCH),1,fp);
        seguidora=seguidora->siguiente;
    }
}

stUsuarioARCH USUaARCH (nodoUser* nodo)
{
 stUsuarioARCH aux;
 strcpy(aux.apellidoYnombres,nodo->dato.apellidoYnombres);
 strcpy(aux.contrasenia,nodo->dato.contrasenia);
 strcpy(aux.mail,nodo->dato.mail);

 aux.categoria=nodo->dato.categoria;
 aux.celular=nodo->dato.celular;
 aux.id=nodo->dato.id;
 aux.estado=nodo->dato.estado;

 aux.validosPlay=PlaylistAArreglo(nodo->playlist,aux);

 return aux;
}

int PlaylistAArreglo(nodoPeli* lista,stUsuarioARCH aux)
{
    int validos=0;
    nodoPeli* seguidora=lista;
    while (seguidora != NULL)
    {
        aux.IdPlaylist[validos]=seguidora->dato.id;
        validos++;
        seguidora=seguidora->siguiente;
    }
    return validos;
}
