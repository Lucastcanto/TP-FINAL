#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Interfaz.h"

///MAIN-----------------------------------------------------------------------------------
int main()
{



    nodoArbol *peliculas=inicArbol();                    ///
    peliculas=DespersistirArchivoPeliculas(peliculas);  ///DESPERSISTENCIA PELI Y MUESTRA
//    InOrderRecorrido(peliculas);                     ///

    nodoUser* listaUsers=inicListaUser();                       ///
    listaUsers=DespersistenciaUsuario(listaUsers,peliculas);   ///DESPERSISTENCIA USUARIOS Y MUESTRA
//    mostrarListaUser(listaUsers);                           ///

    menu_principal(listaUsers,peliculas);

    return 0;
}
