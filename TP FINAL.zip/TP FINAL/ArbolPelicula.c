#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArbolPelicula.h"

nodoArbol* inicArbol ()
{
    return NULL;
}


nodoArbol* crearNodoArbol(stPelicula x)
{
    nodoArbol*aux=(nodoArbol*)malloc(sizeof(nodoArbol));
    aux->peli=x;
    aux->izq=NULL;
    aux->der=NULL;

    return aux;
}

nodoArbol* InsertarEnArbol(nodoArbol* arbol, nodoArbol* nuevoNodo)
{
    if (arbol==NULL)
    {
        arbol=nuevoNodo;
    }
    else
    {
        if (nuevoNodo->peli.id > arbol->peli.id)
        {
            arbol->der=InsertarEnArbol(arbol->der,nuevoNodo);
        }
        else
        {
            arbol->izq=InsertarEnArbol(arbol->izq,nuevoNodo);
        }
    }
    return arbol;
}

nodoArbol* BuscarEnArbol(nodoArbol* arbol,int dato)
{
    nodoArbol*rta=NULL;
    if (arbol != NULL)
    {
        if (dato == arbol->peli.id)
        {
            rta=arbol;
        }
        else
        {
            if (dato > arbol->peli.id)
            {
                rta=BuscarEnArbol(arbol->der,dato);
            }
            else
            {
                rta=BuscarEnArbol(arbol->izq,dato);
            }
        }
    }
    return rta;
}

nodoArbol* BuscarEnArbolxNombre(nodoArbol* arbol,char nombre[])
{
    nodoArbol*rta=NULL;
    if (arbol != NULL)
    {
        if (strcmpi(arbol->peli.nombre,nombre)==0)
        {
            rta=arbol;
        }
        else
        {
            rta=BuscarEnArbolxNombre(arbol->izq,nombre);
            if(rta == NULL)
            {
                rta=BuscarEnArbolxNombre(arbol->der,nombre);
            }
        }
    }
    return rta;
}


void MuestraPelicula (stPelicula x)
{
    printf("\n");
    printf("\n NOMBRE: ");
    puts(x.nombre);
    printf(" ANIO: %i",x.anio);
    printf("\n CALIFICACION: %i",x.calificacion);
    printf("\n GENERO: %s",x.genero);
    printf("\n ID: %i\n",x.id);
    for (int i=0;i < 3;i++)
    {
    printf(" ACTOR %i :\t",i);
    puts(x.actores[i]);
    }
}


void InOrderRecorrido (nodoArbol* arbol)
{
    if (arbol != NULL)
    {
        InOrderRecorrido(arbol->izq);
        MuestraPelicula(arbol->peli);
        InOrderRecorrido(arbol->der);
    }
}

void PreOrdenRecorrido (nodoArbol* arbol)
{
    if (arbol != NULL)
    {
        MuestraPelicula(arbol->peli);
        PreOrdenRecorrido(arbol->der);
        PreOrdenRecorrido(arbol->izq);
    }
}

void PostOrderRecorrido (nodoArbol* arbol)
{
    if (arbol != NULL)
    {
        PostOrderRecorrido(arbol->izq);
        PostOrderRecorrido(arbol->der);
        MuestraPelicula(arbol->peli);
    }
}


int ContarNodos (nodoArbol* arbol)
{
    int contador=0;
    if (arbol != NULL)
    {
        contador=contador + ContarNodos(arbol->izq);
        contador++;
        contador=contador + ContarNodos(arbol->der);
    }
    return contador;
}

nodoArbol* DespersistirArchivoPeliculas(nodoArbol* arbol)
{
    stPelicula AUX;
    nodoArbol* Nodoaux;
    FILE*fp=fopen("Peliculas.bin","rb");
    if (fp != NULL)
    {
        while (fread(&AUX,sizeof(stPelicula),1,fp)>0)
        {
            Nodoaux=crearNodoArbol(AUX);
            arbol=InsertarEnArbol(arbol,Nodoaux);
        }
        fclose(fp);
    }

    return arbol;
}

///BORRAR NODO DE UN ARBOL-----------------------------------


//nodoArbol* nodoMasIzquierda(nodoArbol* arbol)
//{
//    if(arbol)
//    {
//        if(arbol->izq != NULL)
//        {
//            arbol = nodoMasIzquierda(arbol->izq);
//        }
//    }
//    return arbol;
//}
//
//
//nodoArbol* nodoMasDerecha(nodoArbol* arbol)
//{
//    if(arbol)
//    {
//        if(arbol->der != NULL)
//        {
//            arbol = nodoMasDerecha(arbol->der);
//        }
//    }
//    return arbol;
//}
//
//
//int esHoja(nodoArbol * arbol)
//{
//    int rta=0;
//
//    if(arbol)
//    {
//        if(arbol->izq==NULL && arbol->der==NULL)
//        {
//            rta=1;
//        }
//    }
//    return rta;
//}
//
//int esGrado1(nodoArbol * arbol)
//{
//    int rta=0;
//
//    if(arbol)
//    {
//        if( (arbol->izq==NULL && arbol->der!=NULL) || (arbol->izq!=NULL && arbol->der==NULL) )
//        {
//            rta=1;
//        }
//    }
//    return rta;
//}
//
//
//nodoArbol* borrarNodoArbolxID(nodoArbol* arbol, int id)
//{
//    if(arbol != NULL)
//    {
//        if(id > arbol->peli.id)
//        {
//            arbol->der = borrarNodoArbolxID(arbol->der, id);
//        }
//        else if (id < arbol->peli.id)
//        {
//            arbol->izq = borrarNodoArbolxID(arbol->izq, id);
//        }
//        else if (id == arbol->peli.id)
//        {
//            if(esHoja(arbol != NULL))
//            {
//                free(arbol);
//                arbol = NULL;
//            }
//            else if(esGrado1(arbol != NULL))
//            {
//                nodoArbol* aux;
//                if (arbol->der)
//                {
//                    aux = arbol;
//                    arbol = arbol->der;
//                    free(aux);
//                }
//                else
//                {
//                    aux = arbol;
//                    arbol = arbol->izq;
//                    free(aux);
//
//                }
//            }
//            else
//            {
//                nodoArbol* masDer = nodoMasDerecha(arbol->izq);
//                arbol->peli = masDer->peli;
//                arbol->izq = borrarNodoArbolxID(arbol->izq, arbol->peli.id);
//            }
//        }
//    }
//    return arbol;
//}

stPelicula cargarPelicula()
{
    stPelicula aux;
    aux.estado = 1;
    printf("\n");
    printf("\n -NOMBRE=");
    fflush(stdin);
    gets(aux.nombre);
    printf(" -ANIO=");
    scanf("%i",&aux.anio);
    printf("\n -CALIFICACION=");
    scanf("%i",&aux.calificacion);
    printf("\n -GENERO=");
    fflush(stdin);
    gets(aux.genero);


    return aux;
}
int contarPeliculas (nodoArbol* arbol)
{
    int contador=0;
    if (arbol != NULL)
    {
        contador=contador + contarPeliculas(arbol->izq);
        contador++;
        contador=contador + contarPeliculas(arbol->der);
    }
    return contador;
}

void borrarPelicula (nodoArbol* arbol)
{
    char aux [50];
    printf("\nQue pelicula  desea eliminar?");
    fflush(stdin);
    gets(aux);
    nodoArbol* X;
    X = BuscarEnArbolxNombre(arbol,aux);
    if(X == NULL)
    {
        printf("\nPelicula no existente");
    }
    else
    {
        X->peli.estado = 0;
    }

}

nodoArbol* agregarPelicula (nodoArbol* arbol)
{
    nodoArbol* X;
    X = crearNodoArbol(cargarPelicula());
    X->peli.id = contarPeliculas(arbol)+1;
    arbol = agregarAlistaPeli(arbol,X);
    return arbol;
}

void mostrarPelisActivas (nodoArbol* arbol)
{
    if(arbol!=NULL)
    {
        mostrarPelisActivas(arbol->izq);
        if(arbol->peli.estado != 0)
        {
            MuestraPelicula(arbol->peli);
        }
        mostrarPelisActivas(arbol->der);
    }
}

void PersistirArchivoPeliculas(nodoArbol* arbol)
{
    FILE*fp=fopen("Peliculas.bin","wb");
    if (fp != NULL)
    {
        PreOrdenPersitencia(arbol,fp);
        fclose(fp);
    }
}

void PreOrdenPersitencia (nodoArbol* arbol,FILE*fp)
{
    if (arbol != NULL)
    {
        fwrite(&arbol->peli,sizeof(stPelicula),1,fp);
        PreOrdenPersitencia(arbol->der,fp);
        PreOrdenPersitencia(arbol->izq,fp);
    }
}

