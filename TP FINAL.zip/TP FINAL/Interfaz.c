#include <stdio.h>
#include <stdlib.h>
#include "Interfaz.h"

void menu_principal(nodoUser* listaUser,nodoArbol*arbol)
{
    nodoUser* registrado;
    printf("\t\t** Bienvenido A NETLAB **");
    printf("\n\n\tLOGIN...");

    registrado=login(listaUser);
    if (registrado != NULL)
    {
        if (registrado->dato.categoria == 1)
        {
            MenuAdmin(listaUser,arbol,registrado);
        }
        else
        {
            MenuUser(listaUser,arbol,registrado);
        }
    }
}

nodoUser* login(nodoUser* listaUser)
{
    int aux=0;
    int flag=-1;
    char usuarioAUX[20];
    char contraAUX[20];


    printf("\n\nUSUARIO: ");
    fflush(stdin);
    gets(usuarioAUX);

    nodoUser* rta=BuscarUsuarioNombre(listaUser,usuarioAUX);

    if (rta == NULL || rta->dato.estado == 0)
    {
        printf("\nUSUARIO INEXISTENTE...");
        printf("\nDESEA VOLVER A INTENTARLO?");
        int num;
        printf("\n1. SI.\n2. NO \n");
        scanf("%i",&num);            ///FALTA BUCLE QUE PIDA DE NUEVO USUARIO
        switch (num)
        {
        case 1:
            rta=login(listaUser);
            break;
        case 2:
            break;
        }
    }
    else
    {

        while (flag == -1)
        {
            printf("\nPASSWORD: ");
            fflush(stdin);
            gets(contraAUX);

            printf("---------------------------------------");

            aux=VerificarContrasenia(rta,contraAUX);

            if (aux != -1)
            {
                printf("\n\t\t\t** LOGIN SUCCESS **.\n");
                flag=1;
            }
            else
            {
                printf("\nCONTRASE�A INCORRECTA.");
                printf("\nDESEA VOLVER A INTENTARLO?");
                int num;
                printf("\n1. SI.\n2. NO ");
                scanf("%i",&num);
                switch (num)
                {
                case 1:
                    break;
                case 2:
                    flag=2;
                    break;
                }
            }
        }

    }
    if (flag==1)
    {
        return rta;
    }
    else
    {
        return NULL;
    }
}


void MenuAdmin(nodoUser* listaUser,nodoArbol* arbol,nodoUser* registrado)
{
    nodoPeli*listapeli=inicListaPeli();
    int num=0;
    int muestra=0;
    char genero[50];
    printf("\n** (admin) Bienvenido, ");
    puts(registrado->dato.apellidoYnombres);

    while(num != 11)
    {
        printf("\n1. ALTA USUARIO\n2. ALTA PELI\n3. BAJA USUARIO\n4. BAJA PELICULA\n5. MODIIFCAR USER\n6. MODIFICAR PELI\n7. CONSULTAR USUARIO\n8. CONSULTAR PELICULA\n9. MOSTRAR PELIS\n10. MOSTRAR USUARIOS\n11. SAVE & EXIT\t\t\t");
        scanf("%i",&num);

        switch (num)
        {
        case 1:
            listaUser=AltaUsuario(listaUser);
            break;
        case 2:
            arbol=agregarPelicula(arbol);
            break;
        case 3:
            borrarUsuario(listaUser);
            break;
        case 4:
            borrarPelicula(arbol);
            break;
        case 5:
            ModificarUsuario(listaUser);
            break;
        case 6:
            ModificarPeli(arbol);
            break;
        case 7:
            ConsultarUsuario(listaUser);
            break;
        case 8:
            ConsultarPeli(arbol);
            break;
        case 9:
            printf("\nCOMO DESEA MOSTRARLO?\n1. MUESTRA POR ID.\n2. ORDEN ALFABETICO\n3. FECHA DE LANZAMIENTO\n4. GENERO ESPECIFICO\n");
            scanf("%i",&muestra);
            switch (muestra)
            {
            case 1:
                InOrderMuestraAdmin(arbol);
                break;
            case 2:
                listapeli=PasarArbolAListaNombre(arbol,listapeli);
                mostrarListaPlaylist(listapeli);
                break;
            case 3:
                listapeli=PasarArbolAListaFechaLanzamiento(arbol,listapeli);
                mostrarListaPlaylist(listapeli);
                break;
            case 4:
                printf("\nQUE GENERO DESEA BUSCAR?...\t");
                fflush(stdin);
                gets(genero);
                listapeli=PasarArbolAListaXGenero(arbol,listapeli,genero);
                mostrarListaPlaylist(listapeli);
                break;
            }
            break;
        case 10:
            mostrarListaUserAdmin(listaUser);
            break;
        case 11:
            PersistirArchivoPeliculas(arbol);
            PersitenciaListaUsuarios(listaUser);
            break;

        default :
            printf("\n**NUMERO ELEGIDO FUERA DE LAS OPCIONES**\n");
            break;

        }
        printf("\n");
        system("pause");
        system("cls");
    }


}
void MenuUser(nodoUser* listaUser,nodoArbol* arbol,nodoUser* registrado)
{
    int num=0;
    nodoArbol* auxArbol=inicArbol();
    int x=0;
    char genero[50];
    nodoPeli* LISTAPELI=inicListaPeli();
    printf("\n** (user) Bienvenido, ");
    puts(registrado->dato.apellidoYnombres);

    while(num != 9 && registrado->dato.estado == 1)
    {
        printf("\n1. VER PERFIL\n2. MODIFICAR DATOS\n3. BAJA\n4. MOSTRAR PELICULAS\n5. AGREGAR PELICULA A PLAYLIST\n6. ELIMINAR PELICULA DE LA PLAYLIST.\n7. MOSTRAR PELICULA DE LA PLAYLIST\n8. MOSTRAR RECOMENDADAS\n9. SAVE & EXIT\t\t\t");
        scanf("%i",&num);

        switch (num)
        {
        case 1:
            mostrarUser(registrado->dato);
            break;
        case 2:
            ModificarMIUsuario(registrado);
            break;
        case 3:
            MiBaja(registrado);
            PersitenciaListaUsuarios(listaUser);
            break;
        case 4:
            mostrarPelisActivas(arbol);
            break;
        case 5:
            printf("\nINGRESE UNA OPCION...\t\n1. VER LISTA PELICULAS POR ORDEN ALFABETICO\n2. VER POR ORDEN DE ANTIGUEDAD\n3. GENERO EN PARTICULAR\n4. BUSCAR PELICULA POR NOMBRE\n5. IR A SECCION RECOMENDADOS\n");
            scanf("%i",&x);
            switch(x)
            {
            case 1:
                LISTAPELI=PasarArbolAListaNombreUSUARIO(arbol,LISTAPELI);
                mostrarListaPlaylist(LISTAPELI);
                break;

            case 2:
                LISTAPELI=PasarArbolAListaFechaLanzamientoUSUARIO(arbol,LISTAPELI);
                mostrarListaPlaylist(LISTAPELI);
                break;

            case 3:
                printf("\nQUE GENERO DESEA BUSCAR?...\t");
                fflush(stdin);
                gets(genero);
                LISTAPELI=PasarArbolAListaXGeneroUSUARIO(arbol,LISTAPELI,genero);
                mostrarListaPlaylist(LISTAPELI);
                break;

            case 4:
                printf("\nQUE PELICULA DESEA BUSCAR?...\t");
                fflush(stdin);
                gets(genero);
                auxArbol=BuscarEnArbolxNombre(arbol,genero);
                if (auxArbol->peli.estado==1)
                {
                    MuestraPelicula(auxArbol->peli);
                }
                else
                {
                    printf("\n**PELICULA NO DISPONIBLE AL MOMENTO**\n");
                }
                break;

            case 5:

                break;
            default:
                printf("\n**NUMERO ELEGIDO FUERA DE LAS OPCIONES**\n");
                break;
            }
            break;
        case 6:

            break;
        case 7:

            break;
        case 8:

            break;
        case 9:
            PersitenciaListaUsuarios(listaUser);
            break;

        default :
            printf("\n**NUMERO ELEGIDO FUERA DE LAS OPCIONES**\n");
            break;
        }
        printf("\n");
        system("pause");
        system("cls");
    }
    if (registrado->dato.estado==0)
    {
        printf("\n**DEBE SUSCRIBIRSE PARA VER EL CONTENIDO**\n");
    }
}

nodoUser* AltaUsuario(nodoUser* lista)
{
    int aux;
    nodoUser* nuevoNodo;
    int flag=-1;
    nodoUser*name;
    while (flag==-1)
    {
        nuevoNodo=crearnodoUser(CargaUsuario());
        name=BuscarUsuarioNombre(lista,nuevoNodo->dato.apellidoYnombres);

        if (name == NULL)
        {
            flag=1;
        }
        else
        {
            if (name->dato.estado == 0)
            {
                name->dato.estado=1;
                printf("\nEL USUARIO SE DIO DE ALTA");
                flag=1;
            }
            else
            {
                printf("\nEL USUARIO YA EXISTE, INGRESE OTRO...\t");
            }
        }
    }

    if (name==NULL)
    {
        lista=agregarAlistaUser(lista,nuevoNodo);
        nuevoNodo->dato.estado=1;
        nuevoNodo->dato.id=ContarUsuarios(lista);

        printf("\n1.ROL ADMIN\n2.ROL USER\n");
        scanf("%i",&aux);
        if (aux == 1)
        {
            printf("\nROL ADMIN ASIGNADO");
            nuevoNodo->dato.categoria=1;
        }
        else
        {
            printf("\nROL USER ASIGNADO");
            nuevoNodo->dato.categoria=0;
        }
    }

    return lista;
}

void ModificarUsuario(nodoUser* lista)
{
    int x=1;
    char name[50];
    printf("\nQUE USUARIO DESEA MODIFICAR?...");
    fflush(stdin);
    gets(name);

    nodoUser* aux;
    aux=BuscarUsuarioNombre(lista,name);

    if (aux != NULL)
    {
        int num=0;
        printf("\n\tQUE DESEA MODIFICAR?...\n\n1. USUARIO\n2. CONTRASENIA\n3. MAIL\n4. CELULAR\n5. CATEGORIA\n");
        scanf("%i",&num);

        switch(num)
        {
        case 1:
            printf("\nINGRESE NUEVO USUARIO...\t");
            fflush(stdin);
            gets(aux->dato.apellidoYnombres);
            break;

        case 2:
            printf("\nINGRESE NUEVA CONTRASENIA...\t");
            fflush(stdin);
            gets(aux->dato.contrasenia);
            break;

        case 3:
            printf("\nINGRESE NUEVO MAIL...\t");
            fflush(stdin);
            gets(aux->dato.mail);
            break;

        case 4:
            printf("\nINGRESE NUEVO CELULAR...\t");
            scanf("%i",&aux->dato.celular);
            break;

        case 5:
            while ( x < 0 || x > 1)
            {
                printf("\nINGRESE CATEGORIA 1 (ADMIN) Y 0...\t");
                scanf("%i",&x);
                if (x==0 || x==1)
                {
                    aux->dato.categoria=x;
                }
                else
                {
                    printf("\nCOMANDO DESCONOCIDO VUELVA A INTENTAR...\t");
                }
            }
            break;
        }
    }
    else
    {
        printf("\nEL USUARIO NO EXISTE...");
    }
}

void ModificarPeli(nodoArbol* arbol)
{
    int x=0;
    char name[50];
    printf("\nQUE PELI DESEA MODIFICAR?...");
    fflush(stdin);
    gets(name);

    nodoArbol* aux;
    aux=BuscarEnArbolxNombre(arbol,name);

    if (aux != NULL)
    {
        int num=0;
        printf("\n\tQUE DESEA MODIFICAR?...\n\n1. NOMBRE DE PELI\n2. GENERO\n3. ANIO\n4. PUNTUACION\n5. ACTORES\n");
        scanf("%i",&num);

        switch(num)
        {
        case 1:
            printf("\nINGRESE NUEVA PELICULA...\t");
            fflush(stdin);
            gets(aux->peli.nombre);
            break;

        case 2:
            printf("\nINGRESE NUEVO GENERO...\t");
            fflush(stdin);
            gets(aux->peli.genero);
            break;

        case 3:
            printf("\nINGRESE NUEVO ANIO...\t");
            scanf("%i",&aux->peli.anio);
            break;

        case 4:
            printf("\nINGRESE PUNTUACION...\t");
            scanf("%i",&aux->peli.calificacion);
            break;

        case 5:
            for (x=1; x<4; x++)
            {
                printf("\nINGRESE ACTOR %i...\t",x);
                fflush(stdin);
                gets(aux->peli.actores[x]);
            }
            break;
        }
    }
    else
    {
        printf("\nLA PELICULA NO EXISTE...");
    }
}


void ConsultarUsuario(nodoUser* listaUser)
{
    char nombre[50];
    printf("\nQUE USUARIO DESEA BUSCAR?...\t ");
    fflush(stdin);
    gets(nombre);
    nodoUser* aux=BuscarUsuarioNombre(listaUser,nombre);
    if (aux != NULL)
    {
        mostrarUser(aux->dato);
        printf("Categoria: %i",aux->dato.categoria);
        printf("\nEstado: %i",aux->dato.estado);
    }
    else
    {
        printf("\nEL USUARIO NO EXISTE...");
    }
}

void ConsultarPeli(nodoArbol* arbol)
{
    int id;
    printf("\nINGRESE ID:...\t ");
    scanf("%i",&id);
    nodoArbol* aux=BuscarEnArbol(arbol,id);
    if (aux != NULL)
    {
        MuestraPelicula(aux->peli);
        printf(" ESTADO: %i",aux->peli.estado);
    }
    else
    {
        printf("\nLA PELI NO EXISTE...");
    }
}


void InOrderMuestraAdmin (nodoArbol* arbol)
{
    if (arbol != NULL)
    {
        InOrderRecorrido(arbol->izq);
        MuestraPeliculaAdmin(arbol->peli);
        InOrderRecorrido(arbol->der);
    }
}

void MuestraPeliculaAdmin (stPelicula x)
{
    printf("\n");
    printf("\n NOMBRE: ");
    puts(x.nombre);
    printf(" ANIO: %i",x.anio);
    printf("\n CALIFICACION: %i",x.calificacion);
    printf("\n GENERO: %s",x.genero);
    printf("\n ID: %i",x.id);
    printf("\n ESTADO: %i\n",x.estado);
    for (int i=0; i < 3; i++)
    {
        printf(" ACTOR %i :\t",i);
        puts(x.actores[i]);
    }
}

void mostrarUserAdmin(stUsuario x)
{
    printf("\n Nombre: ");
    puts(x.apellidoYnombres);
    printf(" ID:");
    printf("%i",x.id);
    printf("\n Mail:");
    puts(x.mail);
    printf(" Celular:");
    printf(" %i",x.celular);
    printf("\n Contrasenia: ");
    puts(x.contrasenia);
    printf(" Estado: %i",x.estado);
    printf("\n Categoria: %i\n",x.categoria);
}

void mostrarListaUserAdmin(nodoUser*lista)
{
    nodoUser* seguidora=lista;
    while (seguidora != NULL)
    {
        mostrarUserAdmin(seguidora->dato);
        seguidora=seguidora->siguiente;
    }
}

nodoPeli* PasarArbolAListaNombre(nodoArbol* arbol,nodoPeli* lista)
{
    if (arbol != NULL)
    {
        nodoPeli* AUX=crearnodoPeli(arbol->peli);

        lista=SumarAListaPeliOrdenadoXNombre(lista,AUX);

        lista=PasarArbolAListaNombre(arbol->izq,lista);
        lista=PasarArbolAListaNombre(arbol->der,lista);
    }
    return lista;
}

nodoPeli* PasarArbolAListaFechaLanzamiento(nodoArbol* arbol,nodoPeli* lista)
{
    if (arbol != NULL)
    {
        printf(" ");
        nodoPeli* AUX=crearnodoPeli(arbol->peli);

        lista=SumarAListaPeliOrdenadoXFecha(lista,AUX);

        lista=PasarArbolAListaFechaLanzamiento(arbol->izq,lista);
        lista=PasarArbolAListaFechaLanzamiento(arbol->der,lista);
    }
    return lista;
}

nodoPeli* PasarArbolAListaXGenero(nodoArbol* arbol,nodoPeli* lista,char genero[])
{
    if (arbol != NULL)
    {
        nodoPeli* AUX=crearnodoPeli(arbol->peli);
        if (strcmp(genero,AUX->dato.genero) == 0)
        {
            lista=SumarAListaPeliOrdenadoXNombre(lista,AUX);
        }
        lista=PasarArbolAListaXGenero(arbol->izq,lista,genero);
        lista=PasarArbolAListaXGenero(arbol->der,lista,genero);
    }
    return lista;
}

void ModificarMIUsuario(nodoUser* aux)
{

    int num=0;
    printf("\n\tQUE DESEA MODIFICAR?...\n\n1. USUARIO\n2. CONTRASENIA\n3. MAIL\n4. CELULAR\n5. CATEGORIA\n");
    scanf("%i",&num);

    switch(num)
    {
    case 1:
        printf("\nINGRESE NUEVO USUARIO...\t");
        fflush(stdin);
        gets(aux->dato.apellidoYnombres);
        break;

    case 2:
        printf("\nINGRESE NUEVA CONTRASENIA...\t");
        fflush(stdin);
        gets(aux->dato.contrasenia);
        break;

    case 3:
        printf("\nINGRESE NUEVO MAIL...\t");
        fflush(stdin);
        gets(aux->dato.mail);
        break;

    case 4:
        printf("\nINGRESE NUEVO CELULAR...\t");
        scanf("%i",&aux->dato.celular);
        break;

    default :
        printf("\nCOMANDO DESCONOCIDO VUELVA A INTENTAR...\t");
        break;

    }
}

void MiBaja(nodoUser* aux)
{
    aux->dato.estado=0;
}


nodoPeli* PasarArbolAListaNombreUSUARIO(nodoArbol* arbol,nodoPeli* lista)
{
    if (arbol != NULL)
    {
        nodoPeli* AUX=crearnodoPeli(arbol->peli);
        if (arbol->peli.estado==1)
        {
            lista=SumarAListaPeliOrdenadoXNombre(lista,AUX);
        }
        lista=PasarArbolAListaNombreUSUARIO(arbol->izq,lista);
        lista=PasarArbolAListaNombreUSUARIO(arbol->der,lista);
    }
    return lista;
}

nodoPeli* PasarArbolAListaFechaLanzamientoUSUARIO(nodoArbol* arbol,nodoPeli* lista)
{
    if (arbol != NULL)
    {
        printf(" ");
        nodoPeli* AUX=crearnodoPeli(arbol->peli);
        if (arbol->peli.estado==1)
        {
            lista=SumarAListaPeliOrdenadoXFecha(lista,AUX);
        }
        lista=PasarArbolAListaFechaLanzamientoUSUARIO(arbol->izq,lista);
        lista=PasarArbolAListaFechaLanzamientoUSUARIO(arbol->der,lista);
    }
    return lista;
}

nodoPeli* PasarArbolAListaXGeneroUSUARIO(nodoArbol* arbol,nodoPeli* lista,char genero[])
{
    if (arbol != NULL)
    {
        nodoPeli* AUX=crearnodoPeli(arbol->peli);
        if (strcmp(genero,AUX->dato.genero) == 0)
        {
            lista=SumarAListaPeliOrdenadoXNombre(lista,AUX);
        }
        lista=PasarArbolAListaXGeneroUSUARIO(arbol->izq,lista,genero);
        lista=PasarArbolAListaXGeneroUSUARIO(arbol->der,lista,genero);
    }
    return lista;
}
