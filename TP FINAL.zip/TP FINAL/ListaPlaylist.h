#ifndef LISTAPLAYLIST_H_INCLUDED
#define LISTAPLAYLIST_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "ArbolPelicula.h"

typedef struct
{
   stPelicula dato;
   struct nodoPeli*siguiente;
}nodoPeli;

///PROTOTIPADO------------------------------------------------
nodoPeli *inicListaPeli ();
nodoPeli* crearnodoPeli(stPelicula x);
nodoPeli* agregarAlistaPeli(nodoPeli*lista,nodoPeli*nuevoNodo);
void mostrarListaPlaylist(nodoPeli*lista);
nodoPeli* BorrarTodosLosNodosPlaylist(nodoPeli*listaPlay);
nodoPeli* agregarUltimoaPeli (nodoPeli* lista, nodoPeli* nuevoNodo);
void insertarxNombre(nodoPeli* nuevonodo, nodoPeli* lista);
nodoPeli* SumarAListaPeliOrdenadoXNombre(nodoPeli* lista,nodoPeli* nuevonodo);
nodoPeli* BorradorNodoxFecha (nodoPeli* lista, int id);
void insertarxFecha(nodoPeli* nuevonodo, nodoPeli* lista);
nodoPeli* SumarAListaPeliOrdenadoXFecha(nodoPeli* lista,nodoPeli* nuevonodo);
///-----------------------------------------------------------

#endif // LISTAPLAYLIST_H_INCLUDED
