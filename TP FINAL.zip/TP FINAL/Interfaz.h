#ifndef INTERFAZ_H_INCLUDED
#define INTERFAZ_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "ListadeUsuarios.h"

///PROTOTIPADO---------------------------------------------------
void menu_principal(nodoUser* listaUser,nodoArbol*arbol);
nodoUser* login(nodoUser*lista);
void MenuAdmin(nodoUser* listaUser,nodoArbol* arbol,nodoUser* registrado);
void MenuUser(nodoUser* listaUser,nodoArbol* arbol,nodoUser* registrado);
nodoUser* AltaUsuario(nodoUser* lista);
void ModificarUsuario(nodoUser* lista);
void ModificarPeli(nodoArbol* arbol);
void ConsultarUsuario(nodoUser* listaUser);
void ConsultarPeli(nodoArbol* arbol);
void InOrderMuestraAdmin (nodoArbol* arbol);
void MuestraPeliculaAdmin (stPelicula x);  ///NO MUESTRA ESTADO
void mostrarListaUserAdmin(nodoUser*lista);
void mostrarUserAdmin(stUsuario x);
nodoPeli* PasarArbolAListaNombre(nodoArbol* arbol,nodoPeli* lista);
nodoPeli* PasarArbolAListaFechaLanzamiento(nodoArbol* arbol,nodoPeli* lista);
nodoPeli* PasarArbolAListaXGenero(nodoArbol* arbol,nodoPeli* lista,char genero[]);
void ModificarMIUsuario(nodoUser* aux);
void MiBaja(nodoUser* aux);
nodoPeli* PasarArbolAListaNombreUSUARIO(nodoArbol* arbol,nodoPeli* lista);
nodoPeli* PasarArbolAListaFechaLanzamientoUSUARIO(nodoArbol* arbol,nodoPeli* lista);
nodoPeli* PasarArbolAListaXGeneroUSUARIO(nodoArbol* arbol,nodoPeli* lista,char genero[]);
///---------------------------------------------------------------
#endif // INTERFAZ_H_INCLUDED
