#ifndef ARBOLPELICULA_H_INCLUDED
#define ARBOLPELICULA_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int id;
    char nombre[50];
    int anio;
    char genero[30];
    char actores[3][50];
    int calificacion;
    int estado;

}stPelicula;


typedef struct
{
    stPelicula peli;
    struct nodoArbol* izq;
    struct nodoArbol* der;
} nodoArbol;

///PROTOTIPADO----------------------------------------------
nodoArbol* inicArbol ();
nodoArbol* crearNodoArbol(stPelicula x);
nodoArbol* InsertarEnArbol(nodoArbol* arbol, nodoArbol* nuevoNodo);
nodoArbol* BuscarEnArbol(nodoArbol* arbol,int dato);
void InOrderRecorrido (nodoArbol* arbol);
void MuestraPelicula (stPelicula x);
void PreOrdenRecorrido (nodoArbol* arbol);
void PostOrderRecorrido (nodoArbol* arbol);
int ContarNodos (nodoArbol* arbol);
nodoArbol* DespersistirArchivoPeliculas(nodoArbol* arbol);
nodoArbol* BuscarEnArbolxNombre(nodoArbol* arbol,char nombre[]);
nodoArbol* nodoMasIzquierda(nodoArbol* arbol);///
nodoArbol* nodoMasDerecha(nodoArbol* arbol);///
int esHoja(nodoArbol * arbol) ;///                              ///TIRA ERROR
int esGrado1(nodoArbol * arbol) ;///
nodoArbol* borrarNodoArbolxID(nodoArbol* arbol, int id);///
stPelicula cargarPelicula();
int contarPeliculas (nodoArbol* arbol);
void borrarPelicula (nodoArbol* arbol);
nodoArbol* agregarPelicula (nodoArbol* arbol);
void mostrarPelisActivas (nodoArbol* arbol);
void PersistirArchivoPeliculas(nodoArbol* arbol);
void PreOrdenPersitencia (nodoArbol* arbol,FILE*fp);
///---------------------------------------------------------
#endif // ARBOLPELICULA_H_INCLUDED
